const { Sequelize, DataTypes } = require('sequelize');

const sequelize = new Sequelize('sqlite::memory:', {
  logging: false,
});

const Author = sequelize.define('Author', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  birthYear: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
}, {
  timestamps: false,
});

const Book = sequelize.define('Book', {
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  publicationYear: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  pages: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
}, {
  timestamps: false,
});

Author.hasMany(Book, {
  foreignKey: 'authorId',
  as: 'books',
});
Book.belongsTo(Author, {
  foreignKey: 'authorId',
  as: 'author',
});

async function createSampleData() {
  console.log("\n--- Creating Sample Data ---");

  const ronan = await Author.create({ name: 'Ronan The Best', birthYear: 1990 });
  const kim = await Author.create({ name: 'Kim Ang', birthYear: 1995 });
  const hok = await Author.create({ name: 'Hok Tim', birthYear: 2015 });
  console.log(`Created authors: ${ronan.name}, ${kim.name}, ${hok.name}`);

  await ronan.createBook({ title: 'The Sequelize Journey', publicationYear: 2018, pages: 320 });
  await ronan.createBook({ title: 'Node.js Mastery', publicationYear: 2020, pages: 450 });
  await ronan.createBook({ title: 'Database Design Principles', publicationYear: 2022, pages: 280 });
  console.log("Books created for Ronan.");

  await kim.createBook({ title: 'Adventures in Cambodia', publicationYear: 2019, pages: 180 });
  await kim.createBook({ title: 'Khmer Cuisine Delights', publicationYear: 2021, pages: 250 });
  await kim.createBook({ title: 'Travel Photography Tips', publicationYear: 2023, pages: 120 });
  console.log("Books created for Kim.");

  await hok.createBook({ title: 'My First Code', publicationYear: 2024, pages: 50 });
  await hok.createBook({ title: 'AI for Kids', publicationYear: 2025, pages: 80 });
  console.log("Books created for Hok.");
}

async function queryBooksByAuthor(authorName) {
  console.log(`\n--- Fetching all books by '${authorName}' ---`);
  const author = await Author.findOne({ where: { name: authorName } });

  if (author) {
    const books = await author.getBooks();
    if (books.length > 0) {
      books.forEach(book => {
        console.log(`  - Title: ${book.title}, Pub. Year: ${book.publicationYear}, Pages: ${book.pages}`);
      });
    } else {
      console.log(`  No books found for '${authorName}'.`);
    }
  } else {
    console.log(`  Author '${authorName}' not found.`);
  }
}

async function createBookForAuthor(authorName, bookDetails) {
  console.log(`\n--- Creating a new book ('${bookDetails.title}') for '${authorName}' ---`);
  const author = await Author.findOne({ where: { name: authorName } });

  if (author) {
    const newBook = await author.createBook(bookDetails);
    console.log(`  Successfully created book: "${newBook.title}" for ${author.name}.`);
  } else {
    console.log(`  Author '${authorName}' not found. Cannot create book.`);
  }
}

async function listAllAuthorsWithBooks() {
  console.log("\n--- Listing all authors along with their books ---");
  const authors = await Author.findAll({
    include: [{
      model: Book,
      as: 'books',
    }],
    order: [
      ['name', 'ASC'],
      [{ model: Book, as: 'books' }, 'publicationYear', 'ASC']
    ],
  });

  authors.forEach(author => {
    console.log(`\n  Author: ${author.name} (Born: ${author.birthYear})`);
    if (author.books && author.books.length > 0) {
      console.log('    Books:');
      author.books.forEach(book => {
        console.log(`      - "${book.title}" (Pub: ${book.publicationYear}, Pages: ${book.pages})`);
      });
    } else {
      console.log('    No books found for this author.');
    }
  });
}

async function main() {
  try {
    await sequelize.sync({ force: true });
    console.log("Database schema synchronized successfully!");

    await createSampleData();

    await queryBooksByAuthor('Ronan The Best');
    await queryBooksByAuthor('Kim Ang');

    await createBookForAuthor('Kim Ang', {
      title: 'Secrets of Angkor Wat',
      publicationYear: 2024,
      pages: 400
    });
    await queryBooksByAuthor('Kim Ang');

    await listAllAuthorsWithBooks();

  } catch (error) {
    console.error('An error occurred during the exercise:', error);
  } finally {
    await sequelize.close();
    console.log("\nDatabase connection closed.");
  }
}

main();